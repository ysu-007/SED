import numpy as np
import os
import sys
import re
def process_position():
  infile = open('atom.atom')
  outfile = open('Position.data','w')
   # loop ends at the end of file
  box = []
  while(1):
    s = infile.readline()
    if s == '':
        break
    # skip lines in the head of the data file (1 line has been skipped in the first line):
    for i in range(2):
        infile.readline()
    global atoms
    atoms = int(infile.readline())
    s = infile.readline()
    for i in range(3):
        data = infile.readline().split()
        box.append(data)
    global  length_x, length_y, length_z
    length_x = float(box[0][1]) - float(box[0][0])
    length_y = float(box[1][1]) - float(box[1][0])
    length_z = float(box[2][1]) - float(box[2][0])
    s = infile.readline()
    for i in range(0,atoms):
        data=infile.readline().split()
        outfile.write('%s %s %s %s\n'%(data[0],data[1],data[2],data[3]))
  outfile.close()
  infile.close()
  return (atoms,length_x,length_y,length_z) 
def replace(file, old_content, new_content):
   content = read_file(file)
   for i in range(len(old_content)):
     content = content.replace(old_content[i], new_content[i])
   rewrite_file(file, content)

def read_file(file):
   with open(file, encoding='UTF-8') as f:
     read_all = f.read()
     f.close()

   return read_all
def rewrite_file(file, data):
   with open(file, 'w', encoding='UTF-8') as f:
     f.write(data)
     f.close()
def mkdir(filename):
        filepath = 'sed/'+ filename
        os.system('mkdir '+ filepath)
        os.system('cp sed.m '+ filepath)
        os.system('cp process_velocity_data.py '+ filepath)
        os.system('cp Position.data ' + filepath)
        os.system('cp submit_sed.sh ' + filepath)
        os.system('cp submit_tau.sh ' + filepath)
#os.chdir('')
process_position() # process the atom initial position data
Repeat_times = sys.argv[1] # the repeat time of the sed calcualtion to average the result
fmax = sys.argv[2]
frams = sys.argv[3]
Velocitytofile = sys.argv[4]
Marks = sys.argv[5]
Timestep = sys.argv[6]
Dumpstep = sys.argv[7]
os.system('cp sed/sed_initial.m sed.m')
os.system('cp relaxationtime/getsed_initial.m relaxationtime/getsed.m')
os.system('cp lib/process_velocity_data_initial.py process_velocity_data.py')
os.system('cp lib/submit_sed_initial.sh submit_sed.sh')
os.system('cp lib/submit_tau_initial.sh submit_tau.sh')
replace(r'sed.m',['atoms_number','frams','Timestep','Dumpstep','length_x','length_y','length_z'], [str(atoms),str(frams),str(Timestep),str(Dumpstep),str(length_x),str(length_y),str(length_z)])
replace(r'relaxationtime/getsed.m',['fmax','frams','Repeat_times'],[str(fmax),str(frams),str(Repeat_times)])
replace(r'process_velocity_data.py',['Velocitytofile','atoms_number'],[str(Velocitytofile),str(atoms)])
replace(r'submit_sed.sh',['jobname'],[str(Marks)])
replace(r'submit_tau.sh',['jobname','Repeat_times'],[str(Marks),str(Repeat_times)])
for i in range(int(Repeat_times)): # make directory for store data and calculation
    mkdir(str(i+1))
for iterms in ['sed.m', 'Position.data', 'process_velocity_data.py','submit_sed.sh', 'submit_tau.sh']:
    os.remove(iterms)
