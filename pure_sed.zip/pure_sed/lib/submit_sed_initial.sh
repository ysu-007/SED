#!/bin/bash
#SBATCH -p G1Part_sce
#SBATCH -N 1
#SBATCH -n 56
#SBATCH -J syd-sed
source /es01/paratera/parasoft/module.sh
module load intel/20.0.4
module load mpi/intel/20.0.4
export PATH=/es01/paratera/sce1189/software-sce1189/matlab2021b/MATLAB-install/R2021b/bin:$PATH
DATE1=$(date +%s)
python process_velocity_data.py
mpirun -n 1 matlab -nodesktop -nodisplay <sed.m 1>running.log 2>running.err
rm Velocity*
DATE2=$(date +%s)
diff=$((DATE2-DATE1))
dir=`pwd`
echo  "============ sed ${dir:0-1:1} finised ==========" >> ../../state.log
printf "TIME COST: %d DAYS %02d:%02d:%02d\n" \
        $((diff/86400)) $(((diff/3600)%24)) $(((diff/60)%60)) $(($diff %60)) >> ../../state.log

