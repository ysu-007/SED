#!/bin/bash
#SBATCH -p G1Part_sce
#SBATCH -N 1
#SBATCH -n 56
#SBATCH -J syd-tau
source /es01/paratera/parasoft/module.sh
module load intel/20.0.4
module load mpi/intel/20.0.4
export PATH=/es01/paratera/sce1189/software-sce1189/matlab2021b/MATLAB-install/R2021b/bin:$PATH
DATE1=$(date +%s)
python process_velocity_data.py 
mpirun -n 1 matlab -nodesktop -nodisplay <sed.m 1>running1.log 2>running1.err
rm  Velocity*
while [ 1 ];
do
    filenumber=`find ../ -name SEDX.mat | wc -l`
    if [ $filenumber -eq Repeat_times ]; then
            break
    else
            sleep 1800
    fi
done
DATE2=$(date +%s)
diff=$((DATE2-DATE1))
dir=`pwd`
echo "============ sed ${dir:0-1:1} finised ==========" >> ../../state.log
printf "TIME COST: %d DAYS %02d:%02d:%02d\n" \
                $((diff/86400)) $(((diff/3600)%24)) $(((diff/60)%60)) $(($diff %60)) >> ../../state.log
ktotal=`cat running1.log |grep 'ktotal' | awk -F 'is' '{print $2}'`
cd ../../relaxationtime
sed -i "s/ktotal/${ktotal}/g" getsed.m
DATE1=$(date +%s)
mpirun -n 1 matlab -nodesktop -nodisplay <getsed.m 1>running2.log 2>running2.err
DATE2=$(date +%s)
diff=$((DATE2-DATE1))
echo  "============ Tau  finised ==========" >> ../state.log
printf "TIME COST: %d DAYS %02d:%02d:%02d\n" \
                $((diff/86400)) $(((diff/3600)%24)) $(((diff/60)%60)) $(($diff %60)) >> ../state.log
echo "The calculation have finished" >> ../state.log
