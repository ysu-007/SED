import numpy as np
import os
import sys
import re
def process_velocity(dumpfile):
#   frame = 512;
   count = 0;
   infile = open(dumpfile)
   outfile1 = open('Velocity_1.txt','w')
   outfile2 = open('Velocity_2.txt','w')
   outfile3 = open('Velocity_3.txt','w')
   # loop ends at the end of file
   while(1):
      s = infile.readline()
      if s == '':
        break
    # skip 8 lines (1 line has been skipped in the first line):
      for i in range(8):
        infile.readline()
      for i in range(0,atoms_number):
        data=infile.readline().split()
        outfile1.write('%s\n'%(data[1]))
        outfile2.write('%s\n'%(data[2]))
        outfile3.write('%s\n'%(data[3]))
      count = count + 1;
 #     if count%frame == 0:
 #          break
   outfile1.close()
   outfile2.close()
   outfile3.close()
process_velocity('Velocitytofile')
