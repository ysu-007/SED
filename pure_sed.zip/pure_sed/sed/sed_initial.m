clear all;
%==================== Set parameters ===================%
bMax=1;
NMax=atoms_number;
SampleMax=frams;
kSplit=5000;
k1=200; %k point in one k path
kpaths=10;
timestep=Timestep*1e-12;
dumpstep=Dumpstep;
z_repeate=30; %%changing 
%===== k mesh equal the repeated unit cell in directions===================%  changing 
mx=138;
my=30;
mz=30;
%pause(3600)
%1 = 3;
%========= Generating kpoints ===================%

lx=length_x;
ly=length_y;
lz=length_z;
kx=2*pi/lx;
ky=2*pi/ly;
kz=2*pi/lz;
la=lz/z_repeate;

a = [ 1  , 0  , 0 ]*la*sqrt(2)/2;
b = [ 0  , 1  , 0 ]*la*sqrt(2)/2;
c = [ 0  , 0  , 1 ]*la;
a1 =( a + b + c )*0.5;
b1 =( a - b + c )*0.5;
c1 =  a;
det    = a1*cross(b1,c1)';
a_star = 2*pi*cross(b1,c1)/det;
b_star = 2*pi*cross(c1,a1)/det;
c_star = 2*pi*cross(a1,b1)/det;
%special kpoints;
Re_lattice(1,:) = a_star(:);
Re_lattice(2,:) = b_star(:);
Re_lattice(3,:) = c_star(:);
K1 = [ 0   , 0   , 0   ]*Re_lattice(:,:);%G
K2 = [ 0   , 0.5 , 0.5 ]*Re_lattice(:,:);%X
K3 = [ 0.5 , 0.5 , 0.5 ]*Re_lattice(:,:);%L
K4 = [ 0.25, 0.75, 0.5 ]*Re_lattice(:,:);%W
K5 = [ 0.25, 5/8 , 5/8 ]*Re_lattice(:,:);%U
K6 = [ 3/8 , 3/4 , 3/8 ]*Re_lattice(:,:);%K
%path of generating kpoints:G-X-W-K-G-L-U-W-L-K|U-X
kp = zeros(k1*kpaths,3,'single'); % 10 is the totla number of high symmetry paths
size(kp)
calculator = (1:k1)*(1/k1);
I=ones(1,k1);
kp(1  :1*k1,1:3) = (calculator)'*(K2-K1)+I'*K1;
kp(1*k1+1:2*k1,1:3) = (calculator)'*(K4-K2)+I'*K2;
kp(2*k1+1:3*k1,1:3) = (calculator)'*(K6-K4)+I'*K4;
kp(3*k1+1:4*k1,1:3) = (calculator)'*(K1-K6)+I'*K6;
kp(4*k1+1:5*k1,1:3) = (calculator)'*(K3-K1)+I'*K1;
kp(5*k1+1:6*k1,1:3) = (calculator)'*(K5-K3)+I'*K3;
kp(6*k1+1:7*k1,1:3) = (calculator)'*(K4-K5)+I'*K5;
kp(7*k1+1:8*k1,1:3) = (calculator)'*(K3-K4)+I'*K4;
kp(8*k1+1:9*k1,1:3) = (calculator)'*(K6-K3)+I'*K3;
kp(9*k1+1:10*k1,1:3) = (calculator)'*(K2-K5)+I'*K5;
%k mesh paramaters
knumber=0;
for i=1:1:mz+1;
    for j=1:1:my+1;
        for k=1:1:mx+1;
            ux= (k-1)*kx;
            uy= (j-1)*ky;
            uz= (i-1)*kz;
            if( ux>=0 && uy>=0 && uz>=0 && uz<=2*pi/la && ux+uy<=2*sqrt(2)*pi/la && sqrt(2)/3*ux+1/3*uz<=pi/la && sqrt(2)/3*uy+1/3*uz<=pi/la)
                u(knumber+1,1)=ux;
                u(knumber+1,2)=uy;
                u(knumber+1,3)=uz;
                knumber=knumber+1;
            end;
        end;
    end;
end;
%kSplit=knumber;
k_total=size(u);
fprintf('ktotal is %d\n',k_total(1));
% u(knumber+1:1:2*knumber,1)= -u(1:1:knumber,1);
% u(knumber+1:1:2*knumber,2)=  u(1:1:knumber,2);
% u(knumber+1:1:2*knumber,3)=  u(1:1:knumber,3);
% u(2*knumber+1:1:3*knumber,1)=  u(1:1:knumber,1);
% u(2*knumber+1:1:3*knumber,2)= -u(1:1:knumber,2);
% u(2*knumber+1:1:3*knumber,3)=  u(1:1:knumber,3);
% u(3*knumber+1:1:4*knumber,1)=  u(1:1:knumber,1);
% u(3*knumber+1:1:4*knumber,2)=  u(1:1:knumber,2);
% u(3*knumber+1:1:4*knumber,3)= -u(1:1:knumber,3);
% u(4*knumber+1:1:5*knumber,1)= -u(1:1:knumber,1);
% u(4*knumber+1:1:5*knumber,2)= -u(1:1:knumber,2);
% u(4*knumber+1:1:5*knumber,3)=  u(1:1:knumber,3);
% u(5*knumber+1:1:6*knumber,1)= -u(1:1:knumber,1);
% u(5*knumber+1:1:6*knumber,2)=  u(1:1:knumber,2);
% u(5*knumber+1:1:6*knumber,3)= -u(1:1:knumber,3);
% u(6*knumber+1:1:7*knumber,1)=  u(1:1:knumber,1);
% u(6*knumber+1:1:7*knumber,2)= -u(1:1:knumber,2);
% u(6*knumber+1:1:7*knumber,3)= -u(1:1:knumber,3);
% u(7*knumber+1:1:8*knumber,1)= -u(1:1:knumber,1);
% u(7*knumber+1:1:8*knumber,2)= -u(1:1:knumber,2);
% u(7*knumber+1:1:8*knumber,3)= -u(1:1:knumber,3);
% size(u)
% u=unique(u,'rows');
% size(u)
% for i=1:1:size(u(:,1))
%     if (u(i,1)==-kx * mx || u(i,2)==-ky * my || u(i,3)==-kz * mz)
%         u(i,1)=0;
%         u(i,2)=0;
%         u(i,3)=0;
%     end
% end
% u=unique(u,'rows');
% size(u)
%=========get the position of the unit cell==============
ATOM = zeros(NMax,3);
r = zeros(NMax,3,'single');
ATOM = importdata('Position.data');
r(1:NMax,1:3) = single(ATOM(1:NMax,2:4));
%size(k)
clear ATOM;
%=========== loading speed date and time FFT ===================%
%SEDX=zeros(knumber,SampleMax/2,3);
for s=1:3;
    dt = timestep*dumpstep;%time between the dump frame
    fid1=fopen(['Velocity_',num2str(s),'.txt'],'r');
    fprintf('The time spent for read data:\n' )
    tic
    for b=1:bMax;
        for f=1:SampleMax;
            data_v=textscan(fid1,'%f32',NMax);
            v(b,1:NMax,f)=data_v{1};
        end;
    end;
    fclose(fid1);
    toc
    fprintf('The time spent for FFT:\n' )
    tic
    for i=1:1:NMax;
     v(:,i,1:SampleMax)=fft(v(:,i,:),[],3)*dt;
    end
    toc
    v(:,:,SampleMax/2+1:1:SampleMax)=[];
    %============== time integration  ===================%
    for t=1:1:floor(knumber/kSplit)
        KRK = zeros(NMax,kSplit,'single');
        u1=single(u((t-1)*kSplit+1:1:t*kSplit,:));
        KRK = r*u1';
        fprintf('The time spent for sed in phonon dispersion:\n' )
        tic
        vt=zeros(bMax,kSplit,SampleMax/2);%for calculate the time integration
        vt=reshape((reshape(v,[],SampleMax/2)'*exp( 1i*KRK(:,:)  ))',[1 kSplit SampleMax/2]);
        vtt(:,:,:)= (abs(vt) ).^2;
        clear vt
        toc 
        %==============get the result ===================%
        b=ones(1,bMax);
        for j=1:SampleMax/2;
            SEDX((t-1)*kSplit+1:1:t*kSplit,j,s) = b*vtt(:,:,j);
        end;
        clear vtt
    end;
    u1=u(floor(knumber/kSplit)*kSplit+1:1:knumber,:);
    KRK = zeros(NMax,length(u1(:,1)),'single');
    KRK = r*u1';
    vt=zeros(bMax,length(u1(:,1)),SampleMax/2);%for calculate the time integration
    fprintf('The time spent for sed in relaxation time:\n' )
    tic
    vt=reshape((reshape(v,[],SampleMax/2)'*exp( 1i*KRK(:,:)  ))',[1 length(u1(:,1)) SampleMax/2]);
    vtt(:,:,:)= (abs(vt) ).^2;
    clear vt
    toc
    %==============get the result ===================%
    b=ones(1,bMax);
    for j=1:SampleMax/2;
        SEDX(floor(knumber/kSplit)*kSplit+1:1:knumber,j,s) = b*vtt(:,:,j);
    end;
    clear vtt;
    KRK1 = zeros(NMax,k1*kpaths,'single');
    KRK1 = r*kp';
    vt=zeros(bMax,k1*kpaths,SampleMax/2);%for calculate the time integration
    tic
    vt=reshape((reshape(v,[],SampleMax/2)'*exp( 1i*KRK1(:,:)  ))',[1 k1*kpaths SampleMax/2]);
    toc
    vtt(:,:,:)= (abs(vt) ).^2;
    clear vt
    %==============get the phonon dispersion ===================%
    b=ones(1,bMax);
    for j=1:SampleMax/2;
        SED(:,j,s) = b*vtt(:,:,j);
    end;
    clear vtt
end;
SEDX=sum(SEDX,3)/3;
SED=sum(SED,3)/3;
save SED SED
save('SEDX.mat','SEDX','-v7.3');
