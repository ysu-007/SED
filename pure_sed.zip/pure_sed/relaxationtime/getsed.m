clear all
sed1=zeros(2000,24576/2);
sed2=zeros( 33819,24576/2);
cd  ../sed
for i=1:1:9
        file=num2str(i);
        cd (file);
        load SEDX.mat
        load SED.mat
        sed1=sed1+SED;
        sed2=sed2+SEDX;
        cd ..
end
sed1=sed1/9;
sed2=sed2/9;
save sed1 sed1
save sed2 sed2
cd ../relaxationtime
w_interval=20/24576;
x=[0: w_interval: 20/2-w_interval];
t=[];
for i=2:1: 33819
        y=double(sed2(i,:))*1e15;
        disp(i)
        P=findpeaksSLfitting(x,y,0.000000000001,max(y)/1000,3,3,2);
        % pause(0.5)
        %hold off
        t=[t P'];
end
save t t
