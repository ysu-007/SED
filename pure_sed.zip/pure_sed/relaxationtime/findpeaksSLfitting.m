function P=findpeaksSLfitting(x,y,~,~,smoothwidth,smoothwidth1,smoothtype)
% Segmented peak finder: ��Important Note: No more than 3 peaks��
% function P=findpeaksSL(x,y,SlopeThreshold,AmpThreshold,smoothwidth,smoothtype)
% Locates and measures the positive peaks in a noisy x-y time series data.
% Detects peaks by looking for downward zero-crossings in the first
% derivative whose upward slopes exceed SlopeThreshold. Returns list (P)
% containing peak number and relaxation time. Arguments "slopeThreshold",
%"ampThreshold" and "smoothwidth"
% control peak sensitivity of each segment. Higher values will neglect
% smaller features. "Smoothwidth" is a vector of the widths of the smooths
% applied before peak detection; larger values ignore narrow peaks. If
% smoothwidth=0, no smoothing is performed.
% smoothwidth1 is used to sommth the original curve,the number should lower
% than the unmber of data of a peak.
% The argument "smoothtype" determines the smooth algorithm:
%   If smoothtype=1, rectangular (sliding-average or boxcar) If
%   smoothtype=2, triangular (2 passes of sliding-average) If smoothtype=3,
%   pseudo-Gaussian (3 passes of sliding-average)
% See http://terpconnect.umd.edu/~toh/spectrum/Smoothing.html and
% http://terpconnect.umd.edu/~toh/spectrum/PeakFindingandMeasurement.htm
% (c) T.C. O'Haver, 2016.  Version 1, November, 2016  for original peak
% fitting.
%
% Example: Find, measure, and plot 2 noisy peaks with very different widths
%   x=1:.2:100;
%   y=lorentzian(x,20,1.5)+lorentzian(x,80,30)+.02.*randn(size(x));
%   plot(x,y,'c.')
%   P=findpeaksSLfitting(x,y,0.001,0.001,5,3)
%
% Copyright (c) 2016 Thomas C. O'Haver
%
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in
% all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
% THE SOFTWARE.
%
global NUMPEAKS FIXEDPARAMETERS
if nargin~=7;smoothtype=1;end  % smoothtype=1 if not specified in argument
if smoothtype>3;smoothtype=3;end
if smoothtype<1;smoothtype=1;end
if smoothwidth<1;smoothwidth=1;end
if smoothwidth>1,
    d=SegmentedSmooth(deriv(smooth(y,smoothwidth1,'moving')),smoothwidth,smoothtype);
    %first derivative (smooth--->>derivative--->>smooth --->>zero-crossings)
else
    d=deriv(y);
end
P=[0 0 0];
AmpThreshold=max(y)/100;%outo set the AmpThreshold to 1/10 of the heighest peak
plot(x,y,x,d,'linewidth',2);%plot the original curve
hold on
peak=1;
for j=2*round(smoothwidth/2)-1:length(y)-smoothwidth-1,
    if sign(d(j)) > sign (d(j+1)), % Detects zero-crossing
        %if d(j)-d(j+1) > SlopeThreshold, % if slope of derivative is larger than SlopeThreshold
        if y(j) > AmpThreshold,  % if height of peak is larger than AmpThreshold
            P(peak,2) = x(j);
            P(peak,3) = y(j);
            P(peak,1) = peak;
            peak=peak+1; % Move on to next peak
        end
        %end
    end
end
NUMPEAKS=length(P(:,2)); %get the number of peak. If > 3, change the smooth parameters
while (NUMPEAKS>3)
    P=[0 0 0];
    peak=1;
    smoothwidth=smoothwidth+2;
    disp(smoothwidth);
    d=SegmentedSmooth(deriv(smooth(y,smoothwidth1,'moving')),smoothwidth,smoothtype);
    for j=2*round(smoothwidth/2)-1:length(y)-smoothwidth-1,
        if sign(d(j)) > sign (d(j+1)), % Detects zero-crossing
            %if d(j)-d(j+1) > SlopeThreshold, % if slope of derivative is larger than SlopeThreshold
            if y(j) > AmpThreshold,  % if height of peak is larger than AmpThreshold
                P(peak,2) = x(j);
                P(peak,3) = y(j);
                P(peak,1) = peak;
                peak=peak+1; % Move on to next peak
            end
            %end
        end
    end
    NUMPEAKS=length(P(:,2));
end
FIXEDPARAMETERS=P(:,2);% the approximate peak position, the value is use to fit
if NUMPEAKS==1;
    a=FIXEDPARAMETERS(1);
    fun = @(p,x)(p(1)./(((x-p(2))/p(3)).^2+1)); %p(1) is the height of the peak, p(2) is the position of the peak,p(3��is the half width of the peak
    options = optimoptions('lsqcurvefit','MaxIter',1000000,'TolFun',1e-18,...
        'MaxFunEvals',300000,'Algorithm','trust-region-reflective');
    [params,~] = lsqcurvefit(fun,[max(y) a smoothwidth1*(x(2)-x(1))],x,y,...
        [max(y)/10  a-(x(2)-x(1)) (x(2)-x(1))/500],[10*max(y) a+(x(2)-x(1)) 1],options);
    %using the lsqcurvefit method. The initial value is max(y), zero-crossings
    %and smoothwidth1*(x(2)-x(1)).
    %The height of the peak[max(y)/10--->>10*max(y)]
    %The positin of the peak[zero-crossings +- dx(x(2)-x(1))]
    %The half width of the peak[dx/10--->>1]
    yprime = fun(params,x);
    P(1,2)=params(2);%peak position
    P(1,3)=1/params(3)/2;% relaxation time 1/2/halfwidth
  %  plot(x,yprime,'linewidth',2);
end
if NUMPEAKS==2;
    a=FIXEDPARAMETERS(1);
    b=FIXEDPARAMETERS(2);
    fun = @(p,x)(p(1)./(((x-p(2))/p(3)).^2+1)+p(4)./(((x-p(5))/p(6)).^2+1));
    options = optimoptions('lsqcurvefit','MaxIter',1000000,'TolFun',1e-18,...
        'MaxFunEvals',300000,'Algorithm','trust-region-reflective');
    [params,~] = lsqcurvefit(fun,[max(y) a smoothwidth1*(x(2)-x(1)) max(y) b smoothwidth1*(x(2)-x(1))],x,y,...
        [max(y)/10  a-(x(2)-x(1)) (x(2)-x(1))/500 max(y)/10 b-(x(2)-x(1)) (x(2)-x(1))/500],...
        [10*max(y) a+(x(2)-x(1)) 1 10*max(y) b+(x(2)-x(1)) 1],options);
    yprime = fun(params,x);
    P(1,2)=params(2);
    P(2,2)=params(5);
    P(1,3)=1/params(3)/2;
    P(2,3)=1/params(6)/2;
   % plot(x,yprime,'linewidth',2);
end
if NUMPEAKS==3
    a=FIXEDPARAMETERS(1);
    b=FIXEDPARAMETERS(2);
    c=FIXEDPARAMETERS(3);
    fun = @(p,x)(p(1)./(((x-p(2))/p(3)).^2+1)+p(4)./(((x-p(5))/p(6)).^2+1)+p(7)./(((x-p(8))/p(9)).^2+1));
    options = optimoptions('lsqcurvefit','MaxIter',1000000,'TolFun',1e-18,...
        'MaxFunEvals',3000000,'Algorithm','trust-region-reflective');
    [params,~] = lsqcurvefit(fun,[max(y) a smoothwidth1*(x(2)-x(1)) max(y) b smoothwidth1*(x(2)-x(1)) max(y) c smoothwidth1*(x(2)-x(1))],...
        x,y,[max(y)/10  a-(x(2)-x(1)) (x(2)-x(1))/500 max(y)/10 b-(x(2)-x(1)) (x(2)-x(1))/500 max(y)/10 c-(x(2)-x(1)) (x(2)-x(1))/500],...
        [10*max(y) a+(x(2)-x(1)) 1 10*max(y) b+(x(2)-x(1)) 1 10*max(y) c+(x(2)-x(1)) 1],options);
    yprime = fun(params,x);
    P(1,2)=params(2);
    P(2,2)=params(5);
    P(3,2)=params(8);
    P(1,3)=1/params(3)/2;
    P(2,3)=1/params(6)/2;
    P(3,3)=1/params(9)/2;
   % plot(x,yprime,'linewidth',2);
end
% ----------------------------------------------------------------------

function d=deriv(a)
% First derivative of vector using 2-point central difference.
%  T. C. O'Haver, 1988.
n=length(a);
d=zeros(size(a));
d(1)=a(2)-a(1);
d(n)=a(n)-a(n-1);
for j = 2:n-1;
    d(j)=(a(j+1)-a(j-1)) ./ 2;
end


function SmoothedSignal=SegmentedSmooth(y,smoothwidths,type,ends)
%   SegmentedSmooth(y,w,type,ends) divides y into a number of equal-length
%   segments defined by the length of the vector 'smoothwidths', then
%   smooths each segment with smooth of type 'type' and width defined by
%   the elements of vector 'smoothwidths'.
%    Version 1, November 2016.
%   The argument "type" determines the smooth type:
%     If type=1, rectangular (sliding-average or boxcar)
%     If type=2, triangular (2 passes of sliding-average)
%     If type=3, pseudo-Gaussian (3 passes of sliding-average)
%     If type=4, pseudo-Gaussian (4 passes of same sliding-average)
%     If type=5, multiple-width (4 passes of different sliding-averages)
%   The argument "ends" controls how the "ends" of the signal
%   (the first w/2 points and the last w/2 points) are handled.
%     If ends=0, the ends are zero. (In this mode the elapsed
%       time is the fastest and is independent of the smooth width).
%     If ends=1, the ends are smoothed with progressively
%       smaller smooths the closer to the end. (In this mode the
%       elapsed time increases with increasing smooth widths).
%   SegmentedSmooth(Y,w,type) smooths with ends=0.
%   SegmentedSmooth(Y,w) smooths with type=1 and ends=0.
%
%   Examples: 3-segment smooth of random white noise, smooth widths of
%   2,20, and 200.
%     x=1:10000;y=randn(size(x));
%     plot(x,SegmentedSmooth(y,[2 20 200],3,0))
%
%     20-segment smooth, odd smooth widths from 1 to 41:
%     plot(x,SegmentedSmooth(y,[1:2:41],3,0))

%   Copyright (c) 2012, Thomas C. O'Haver

if nargin==2, ends=0; type=1; end
if nargin==3, ends=0; end
ly=length(y);
NumSegments=length(smoothwidths);
SegLength=round(ly./NumSegments);
SmoothSegment=zeros(ly,NumSegments);
SmoothedSignal=zeros(1,ly);
for Segment=1:NumSegments,
    SmoothSegment(:,Segment)=fastsmooth(y,smoothwidths(Segment),type,ends);
    startindex=(1+(Segment-1)*SegLength);
    endindix=startindex+SegLength-1;
    if endindix>ly,endindix=ly;end
    indexrange=startindex:endindix;
    SmoothedSignal(indexrange)=SmoothSegment(indexrange,Segment);
end


function SmoothY=fastsmooth(Y,w,type,ends)
% fastsmooth(Y,w,type,ends) smooths vector Y with smooth
%  of width w. Version 3.0, October 2016.
% The argument "type" determines the smooth type:
%   If type=1, rectangular (sliding-average or boxcar)
%   If type=2, triangular (2 passes of sliding-average)
%   If type=3, pseudo-Gaussian (3 passes of sliding-average)
%   If type=4, pseudo-Gaussian (4 passes of same sliding-average)
%   If type=5, multiple-width (4 passes of different sliding-average)
% The argument "ends" controls how the "ends" of the signal
% (the first w/2 points and the last w/2 points) are handled.
%   If ends=0, the ends are zero.  (In this mode the elapsed
%     time is independent of the smooth width). The fastest.
%   If ends=1, the ends are smoothed with progressively
%     smaller smooths the closer to the end. (In this mode the
%     elapsed time increases with increasing smooth widths).
% fastsmooth(Y,w,type) smooths with ends=0.
% fastsmooth(Y,w) smooths with type=1 and ends=0.
% Examples:
% fastsmooth([1 1 1 10 10 10 1 1 1 1],3)= [0 1 4 7 10 7 4 1 1 0]
%
% fastsmooth([1 1 1 10 10 10 1 1 1 1],3,1,1)= [1 1 4 7 10 7 4 1 1 1]
%
% x=1:100;
% y=randn(size(x));
% plot(x,y,x,fastsmooth(y,5,3,1),'r')
% xlabel('Blue: white noise.    Red: smoothed white noise.')
%
% Copyright (c) 2012, Thomas C. O'Haver
%
switch type
    case 1
        SmoothY=sa(Y,w,ends);
    case 2
        SmoothY=sa(sa(Y,w,ends),w,ends);
    case 3
        SmoothY=sa(sa(sa(Y,w,ends),w,ends),w,ends);
    case 4
        SmoothY=sa(sa(sa(sa(Y,w,ends),w,ends),w,ends),w,ends);
    case 5
        SmoothY=sa(sa(sa(sa(Y,round(1.6*w),ends),round(1.4*w),ends),round(1.2*w),ends),w,ends);
end

function SmoothY=sa(Y,smoothwidth,ends)
w=round(smoothwidth);
SumPoints=sum(Y(1:w));
s=zeros(size(Y));
halfw=round(w/2);
L=length(Y);
for k=1:L-w,
    s(k+halfw-1)=SumPoints;
    SumPoints=SumPoints-Y(k);
    SumPoints=SumPoints+Y(k+w);
end
s(k+halfw)=sum(Y(L-w+1:L));
SmoothY=s./w;
% Taper the ends of the signal if ends=1.
if ends==1,
    startpoint=(smoothwidth + 1)/2;
    SmoothY(1)=(Y(1)+Y(2))./2;
    for k=2:startpoint,
        SmoothY(k)=mean(Y(1:(2*k-1)));
        SmoothY(L-k+1)=mean(Y(L-2*k+2:L));
    end
    SmoothY(L)=(Y(L)+Y(L-1))./2;
end
% ----------------------------------------------------------------------



