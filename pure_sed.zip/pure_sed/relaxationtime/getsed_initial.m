clear all
sed1=zeros(2000,frams/2);
sed2=zeros(ktotal,frams/2);
cd  ../sed
for i=1:1:Repeat_times
        file=num2str(i);
        cd (file);
        load SEDX.mat
        load SED.mat
        sed1=sed1+SED;
        sed2=sed2+SEDX;
        cd ..
end
sed1=sed1/Repeat_times;
sed2=sed2/Repeat_times;
save sed1 sed1
save sed2 sed2
cd ../relaxationtime
w_interval=fmax/frams;
x=[0: w_interval: fmax/2-w_interval];
t=[];
for i=2:1:ktotal
        y=double(sed2(i,:))*1e15;
        disp(i)
        P=findpeaksSLfitting(x,y,0.000000000001,max(y)/1000,3,3,2);
        % pause(0.5)
        %hold off
        t=[t P'];
end
save t t
