#!/bin/bash
#SBATCH -p G1Part_sce
#SBATCH -N 2
#SBATCH -n 112
#SBATCH -J syd_lmp
module load lammps/29sep21
mpirun -np 112 lmp_intel_cpu_intelmpi  -in sed.lmp
DATE2=$(date +%s)
diff=$((DATE2-DATE1))

echo "=========== MD job finised =========" >> state.log
printf "TIME COST: %d DAYS %02d:%02d:%02d\n" \
                $((diff/86400)) $(((diff/3600)%24)) $(((diff/60)%60)) $(($diff %60)) >> state.log

